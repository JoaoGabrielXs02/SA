function playMusic(musicFile, title, description) {
    const playerUrl = `player.html?src=${encodeURIComponent(musicFile)}&title=${encodeURIComponent(title)}&description=${encodeURIComponent(description)}`;
    window.location.href = 'musica.html';;
  }