 // Recebe os parâmetros da URL
 const params = new URLSearchParams(window.location.search);
 const musicSrc = params.get('src');
 const title = params.get('title');
 const description = params.get('description');

 // Atualiza o conteúdo do player
 document.getElementById('audio-source').src = musicSrc;
 document.getElementById('music-title').textContent = title;
 document.getElementById('music-description').textContent = description;
 document.getElementById('audio-player').load();
